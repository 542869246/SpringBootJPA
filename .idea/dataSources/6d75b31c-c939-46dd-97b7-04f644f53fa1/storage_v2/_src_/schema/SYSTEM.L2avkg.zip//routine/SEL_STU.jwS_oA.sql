CREATE PROCEDURE SEL_STU(V_STUNO   IN STUINFO.STUNO%TYPE DEFAULT '67D24A528B64F94A1FB8E80ED99BD88',
                                    V_STUNAME OUT STUINFO.STUNAME%TYPE,
                                    V_STUAGE  IN OUT STUINFO.STUAGE%TYPE,
                                    ON_FLAG   OUT NUMBER,
                                    OS_MSG    OUT VARCHAR2) AS
  V_COUNT NUMBER(38);
BEGIN
  SELECT COUNT(*) INTO V_COUNT FROM STUINFO;
  IF V_COUNT > 0 THEN
    SELECT STUNAME, STUAGE
      INTO V_STUNAME, V_STUAGE
      FROM STUINFO
     WHERE STUNO = V_STUNO;
    ON_FLAG := 1;
    OS_MSG  := '查询成功';
  ELSIF V_COUNT IS NULL THEN
    ON_FLAG := -1;
    OS_MSG  := '查无数据';
  ELSE
    ON_FLAG := -2;
    OS_MSG  := '其他异常';
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    ON_FLAG := -3;
    OS_MSG  := '查无数据';
  WHEN OTHERS THEN
    ON_FLAG := -4;
    OS_MSG  := '其他异常';
END;
/

