CREATE PROCEDURE ADD_STU(STUNO   VARCHAR2,
                                    STUNAME VARCHAR2,
                                    STUAGE  NUMBER,
                                    STUID   NUMBER,
                                    STUSEAT NUMBER,
                                    STUTEST VARCHAR2,
                                    ON_FLAG OUT NUMBER,
                                    OS_MSG  OUT VARCHAR2) IS
BEGIN
  INSERT INTO STUINFO
  VALUES
    (STUNO, STUNAME, STUAGE, STUID, STUSEAT, STUTEST);
  ON_FLAG := 1;
  OS_MSG  := '添加成功';
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    ON_FLAG := -1;
    OS_MSG  := '已存在';
  WHEN OTHERS THEN
    ON_FLAG := -2;
    OS_MSG  := '其他错误';
END;
/

