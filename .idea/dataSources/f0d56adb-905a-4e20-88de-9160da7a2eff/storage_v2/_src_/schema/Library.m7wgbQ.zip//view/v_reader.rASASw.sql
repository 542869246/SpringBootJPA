CREATE VIEW v_reader AS
  SELECT
    `library`.`book`.`bName`                                                                                  AS `书名`,
    `library`.`book`.`bCount`                                                                                 AS `库存`,
    (SELECT count(0)
     FROM `library`.`borrow`
     WHERE ((`library`.`borrow`.`nif` = `library`.`book`.`bid`) AND isnull(
         `library`.`borrow`.`returnDate`)))                                                                   AS `已借出数量`,
    (`library`.`book`.`bCount` + (SELECT count(0)
                                  FROM `library`.`borrow`
                                  WHERE ((`library`.`borrow`.`nif` = `library`.`book`.`bid`) AND
                                         isnull(`library`.`borrow`.`returnDate`))))                           AS `总数量`
  FROM `library`.`book`;

