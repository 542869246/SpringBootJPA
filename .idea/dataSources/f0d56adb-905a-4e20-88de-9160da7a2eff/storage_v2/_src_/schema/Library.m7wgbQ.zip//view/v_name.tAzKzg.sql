CREATE VIEW v_name AS
  SELECT
    `library`.`borrow`.`rid`        AS `rid`,
    `library`.`borrow`.`nif`        AS `nif`,
    `library`.`borrow`.`lendDate`   AS `lendDate`,
    `library`.`borrow`.`willDate`   AS `willDate`,
    `library`.`borrow`.`returnDate` AS `returnDate`
  FROM `library`.`borrow`
  ORDER BY `library`.`borrow`.`rid`
  LIMIT 1;

